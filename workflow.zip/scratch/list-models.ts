import dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function listModels() {
  const apiKey = process.env.GOOGLE_AI_API_KEY || process.env.GOOGLE_CLOUD_API_KEY;
  const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`;

  try {
    const res = await fetch(url);
    const json = await res.json();
    
    if (json.models) {
      const audioModels = json.models.filter((m: any) => 
        m.name.toLowerCase().includes('tts') || 
        m.name.toLowerCase().includes('audio') ||
        (m.supportedGenerationMethods && m.supportedGenerationMethods.includes('generateContent'))
      );
      
      console.log("All TTS/Audio related models:");
      json.models.forEach((m: any) => {
        if (m.name.includes("tts") || m.name.includes("2.5") || m.name.includes("2.0")) {
          console.log(`- ${m.name} (Methods: ${m.supportedGenerationMethods?.join(', ')})`);
        }
      });
    } else {
      console.log(json);
    }
  } catch (err) {
    console.error(err);
  }
}

listModels();
