import { synthesizeVoiceover } from '../src/lib/tts/synthesize-voiceover';
import { resolveVoicePersona } from '../src/lib/tts/voices';
import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' }); // Root is ai-realestate-video

async function test() {
  const voice = resolveVoicePersona("Achernar", "kn-IN");
  const text = "2 point 40 acre agricultural land near Mysore, ಕೇವಲ 25 ಕಿಲೋಮೀಟರ್. Bannur 7 ಕಿಲೋಮೀಟರ್, Bangalore 120 ಕಿಲೋಮೀಟರ್.";
  try {
    console.log("Synthesizing voiceover...");
    const res = await synthesizeVoiceover(text, voice);
    console.log("Success! Provider:", res.ttsProvider);
    console.log("Duration Ms:", res.durationMs);
    console.log("Sync Source:", res.sync.syncSource);
    console.log("Words timestamps count:", res.sync.words.length);
    console.log("Sentences count:", res.sync.sentences.length);
    console.log("Words details:");
    console.dir(res.sync.words.slice(0, 15), { depth: null });
  } catch (err) {
    console.error("Failed!", err);
  }
}
test();
