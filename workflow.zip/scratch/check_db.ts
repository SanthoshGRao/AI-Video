import prisma from '../src/lib/db/prisma';

async function run() {
  const audio = await prisma.audioAsset.findFirst({
    orderBy: { createdAt: 'desc' }
  });
  console.log("Word timestamps from DB:");
  console.log(JSON.stringify(audio?.wordTimestamps, null, 2));
}

run().catch(console.error).finally(() => prisma.$disconnect());
