import { synthesizeVoiceover } from '../src/lib/tts/synthesize-voiceover';
import { resolveVoicePersona } from '../src/lib/tts/voices';
import * as dotenv from 'dotenv';
dotenv.config({ path: '../.env.local' });

async function test() {
  const voice = resolveVoicePersona("Hindi + English Realtor");
  try {
    const res = await synthesizeVoiceover("Hello this is a test. We are testing English voiceover.", voice);
    console.log("Success! Provider:", res.ttsProvider);
  } catch (err) {
    console.error("Failed!", err);
  }
}
test();
