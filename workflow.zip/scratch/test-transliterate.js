const fs = require('fs');
async function test() {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "Transliterate all English words in this text into Kannada script phonetically. Output ONLY the resulting mixed Kannada string without any English characters: 2 point 2 acre farmland near Mysore, ಇದು weekend farmhouse ಗೆ perfect ಪ್ರಶ್ನೆ. Mysuru 25 ಕಿಲೋಮೀಟರ್, tranquil environment, nearby waterfall ಇದೆ." }], role: "user" }]
    })
  });
  const json = await res.json();
  const kannadaOnly = json.candidates[0].content.parts[0].text;
  console.log("Transliterated: ", kannadaOnly);

  const ttsUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const ttsRes = await fetch(ttsUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: kannadaOnly }], role: "user" }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Aoede" } } }
      }
    })
  });
  const ttsJson = await ttsRes.json();
  console.log("TTS Result: ", ttsJson.candidates?.[0]?.finishReason);
}
test();
