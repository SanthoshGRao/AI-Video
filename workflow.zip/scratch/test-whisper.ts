import prisma from '../src/lib/db/prisma';
import fs from 'fs';
import { alignWordsWithStableTs } from '../src/lib/tts/stable-ts-align';

async function run() {
  const audio = await prisma.audioAsset.findFirst({ orderBy: { createdAt: 'desc' } });
  if (!audio) return console.log("No audio");
  if (!audio.localPath) return console.log("No localPath for audio");

  const buffer = fs.readFileSync(audio.localPath);
  console.log("Audio loaded, length:", buffer.length);

  console.log("Testing with prompt:", audio.wordTimestamps ? "yes" : "no");
  
  const words = await alignWordsWithStableTs({
    audioBuffer: buffer,
    scriptText: "Fast moving deal near Mysore! 1 point 22 acre coconut land",
    fileExtension: audio.localPath.endsWith(".wav") ? "wav" : "mp3",
  });
  if (words.length > 0) {
    console.log("First word start:", words[0].start, "word:", words[0].word);
  } else {
    console.log("No words returned");
  }
}
run().catch(console.error).finally(() => prisma.$disconnect());
