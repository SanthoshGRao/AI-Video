import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function check() {
  try {
    const { default: prisma } = await import('../src/lib/db/prisma');
    const project = await prisma.project.findFirst({
      orderBy: { updatedAt: "desc" },
      include: {
        audioAssets: {
          orderBy: { createdAt: "desc" }
        },
        subtitleTracks: {
          orderBy: { createdAt: "desc" }
        }
      }
    });

    if (!project) {
      console.log("No project found");
      return;
    }

    console.log("Project Title:", project.title);
    console.log("Project ID:", project.id);
    console.log("Audio Assets count:", project.audioAssets.length);
    if (project.audioAssets.length > 0) {
      const audio = project.audioAssets[0];
      console.log("Latest Audio ID:", audio.id);
      console.log("Latest Audio syncSource:", (audio.wordTimestamps as any)?.syncSource);
    }
    console.log("Subtitle Tracks count:", project.subtitleTracks.length);
    if (project.subtitleTracks.length > 0) {
      const sub = project.subtitleTracks[0];
      console.log("Latest Subtitle Track ID:", sub.id);
      console.log("Latest Subtitle Track cues count:", (sub.cues as any)?.length);
    }
  } catch (e) {
    console.error("Error:", e);
  }
}
check();
