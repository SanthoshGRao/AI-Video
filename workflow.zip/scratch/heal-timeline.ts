import prisma from '../src/lib/db/prisma';
import { parseTimelineRow, syncTrackClipIds } from '../src/lib/timeline/parse';

async function main() {
  const p = await prisma.project.findFirst({orderBy: {updatedAt: 'desc'}});
  if (!p) {
    console.log("No project found");
    return;
  }
  const timeline = await prisma.timeline.findFirst({
    where: { projectId: p.id },
    orderBy: [{ version: "desc" }, { createdAt: "desc" }],
  });
  if (!timeline) {
    console.log("No timeline found");
    return;
  }

  console.log("Found project:", p.title, `(${p.id})`);
  const doc = parseTimelineRow(timeline);
  let updatedCount = 0;

  // Move text/title clips on track-1 or track-video to track-3 (which is track-text / Text 1)
  for (const clip of Object.values(doc.clips)) {
    const isTitle = clip.type === "text" || clip.id.startsWith("title-clip") || (clip.properties as any)?.textOverlayMeta?.category === "title";
    if (isTitle && (clip.trackId === "track-1" || clip.trackId === "track-video")) {
      console.log(`Healing clip ${clip.id} ("${(clip.properties as any)?.text || clip.id}"): track-1 -> track-3`);
      clip.trackId = "track-3";
      updatedCount++;
    }
  }

  if (updatedCount > 0) {
    // Re-sync track clipIds based on corrected clip trackIds
    const syncedDoc = syncTrackClipIds(doc);

    // Make sure track-3 exists in tracks list
    let textTrack = syncedDoc.tracks.find(t => t.id === "track-3");
    if (!textTrack) {
      console.log("Adding missing track-3 to tracks list");
      syncedDoc.tracks.push({
        id: "track-3",
        name: "Text 1",
        type: "text",
        muted: false,
        locked: false,
        clipIds: Object.values(syncedDoc.clips).filter(c => c.trackId === "track-3").map(c => c.id)
      });
    }

    await prisma.timeline.update({
      where: { id: timeline.id },
      data: {
        clips: syncedDoc.clips as any,
        tracks: syncedDoc.tracks as any,
        transitions: syncedDoc.transitions as any,
        textLayers: syncedDoc.textLayers as any,
        settings: syncedDoc.settings as any,
      }
    });

    console.log(`Successfully healed ${updatedCount} clips and updated timeline in DB!`);
  } else {
    console.log("No clips needed healing.");
  }
}

main().catch(console.error);
