import { readFileSync } from 'fs';
import prisma from '../src/lib/db/prisma';
async function run() {
  const audio = await prisma.audioAsset.findFirst({ orderBy: { createdAt: 'desc' } });
  if (audio) {
    console.log(JSON.stringify(audio.wordTimestamps, null, 2));
  } else {
    console.log("No audio found.");
  }
}
run().catch(console.error).finally(()=>prisma.$disconnect());
