import prisma from '../src/lib/db/prisma';
import { parseAudioSync } from '../src/lib/tts/types.js';
import { cuesFromAudioSync } from '../src/lib/subtitles/cues.js';



async function run() {
  const audio = await prisma.audioAsset.findFirst({ orderBy: { createdAt: 'desc' } });
  if (!audio) {
    console.log("No audio found.");
    return;
  }
  
  console.log("Audio ID:", audio.id);
  console.log("WordTimestamps length in DB:", (audio.wordTimestamps as any)?.words?.length);

  const sync = parseAudioSync(audio.wordTimestamps);
  if (!sync) {
    console.log("parseAudioSync returned null!");
    return;
  }
  console.log("Parsed Sync Words:", sync.words.length);

  const cues = cuesFromAudioSync(sync, { maxCharsPerCue: 100 });
  console.log("Generated Cues:", cues.length);
  if (cues.length > 0) {
    console.log("First Cue:", cues[0]);
    console.log("Last Cue:", cues[cues.length - 1]);
  }
}

run().catch(console.error).finally(()=>prisma.$disconnect());
