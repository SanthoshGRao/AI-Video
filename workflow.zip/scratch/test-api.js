const fs = require('fs');
async function test() {
  const url = `http://localhost:3000/api/projects/cmploxl7t000n70uqaztdgyk1/generate-voiceover`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" }
  });
  console.log(res.status);
  const text = await res.text();
  console.log(text.substring(0, 500));
}
test();
