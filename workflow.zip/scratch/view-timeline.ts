import prisma from '../src/lib/db/prisma';
import { parseTimelineRow } from '../src/lib/timeline/parse';

async function main() {
  const p = await prisma.project.findFirst({orderBy: {updatedAt: 'desc'}});
  if (!p) {
    console.log("No project found");
    return;
  }
  const timeline = await prisma.timeline.findFirst({
    where: { projectId: p.id },
    orderBy: [{ version: "desc" }, { createdAt: "desc" }],
  });
  if (!timeline) {
    console.log("No timeline found");
    return;
  }
  console.log("PROJECT ID:", p.id);
  console.log("TIMELINE TRACKS:", JSON.stringify(timeline.tracks, null, 2));
  console.log("TIMELINE CLIPS:", JSON.stringify(timeline.clips, null, 2));
}

main().catch(console.error);
