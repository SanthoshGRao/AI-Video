const { synthesizeVoiceover } = require('./src/lib/tts/synthesize-voiceover');
const { resolveVoicePersona } = require('./src/lib/tts/voices');

async function test() {
  const voice = resolveVoicePersona("Hindi + English Realtor");
  try {
    const res = await synthesizeVoiceover("Hello this is a test. We are testing English voiceover.", voice);
    console.log("Success! Provider:", res.ttsProvider);
  } catch (err) {
    console.error("Failed!", err);
  }
}
test();
