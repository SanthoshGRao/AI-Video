const fs = require('fs');
async function test() {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "ಮೈಸೂರು 25 ಕಿಲೋಮೀಟರ್, ಟ್ರ್ಯಾಂಕ್ವಿಲ್ ಎನ್ವಿರಾನ್‌ಮೆಂಟ್, ನಿಯರ್‌ಬೈ ವಾಟರ್‌ಫಾಲ್ ಇದೆ. ಈಸಿ ಮೇಂಟೆನೆನ್ಸ್, ಇರಿಗೇಶನ್ ಸೆಟಪ್ ರೆಡಿ, ವಾಟರ್ ಆವಶ್ಯಕತೆಗಳ ಟೆನ್ಶನ್ ಇಲ್ಲ. ಫುಲ್ ಎಲೆಕ್ಟ್ರಿಸಿಟಿ ಅವೈಲಬಲ್ ಇದರಿಂದ ಆರಾಮದಾಯಕ ಸೆಟ್ಟಿಂಗ್ ಇದೆ. ಐಡಿಯಲ್ ಫಾರ್ ಕಾಮ್ ಫಾರ್ಮ್‌ಹೌಸ್ ಸೆಟಪ್ಸ್. ವೀಕೆಂಡ್ ಹೋಗಿ ಫ್ರೆಶ್ ಬ್ರೆತ್ ಆನಂದಿಸಿ. ಮರೆಯದೆ, ಜೊತೆಗೆ ತಕ್ಷಣ ಸಂಪರ್ಕಿಸಿ. ನನಗೂ ಇದು ಬಿಸಿನೆಸ್ ಆಗಬೇಕು! ಸೈಟ್ ವಿಸಿಟ್ ಗೇ ವಾಟ್ಸ್ಯಾಪ್ ನಲ್ಲಿ ಡಿ ಎಂ ಮಾಡಿ." }], role: "user" }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Aoede" } } }
      },
      safetySettings: [
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
      ]
    })
  });
  console.log(res.status);
  const json = await res.json();
  console.log(JSON.stringify(json, null, 2));
}
test();
