import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function check() {
  try {
    const { default: prisma } = await import('../src/lib/db/prisma');
    
    const project = await prisma.project.findFirst({
      orderBy: { updatedAt: "desc" },
      include: {
        audioAssets: {
          orderBy: { createdAt: "desc" },
          take: 1
        }
      }
    });

    if (!project) {
      console.log("No projects found");
      return;
    }

    console.log("Project Title:", project.title);
    console.log("Project ID:", project.id);
    
    const audio = project.audioAssets[0];
    if (!audio) {
      console.log("No audio assets found");
      return;
    }

    console.log("Audio ID:", audio.id);
    console.log("Duration:", audio.durationMs);
    console.log("Word Timestamps Count:", (audio.wordTimestamps as any)?.words?.length || (audio.wordTimestamps as any)?.length);
    console.log("Word Timestamps Sync Source:", (audio.wordTimestamps as any)?.syncSource);
    console.log("First 15 words:");
    console.dir((audio.wordTimestamps as any)?.words?.slice(0, 15) || (audio.wordTimestamps as any)?.slice(0, 15), { depth: null });
  } catch (e) {
    console.error("Error:", e);
  }
}
check();
