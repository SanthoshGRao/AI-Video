import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function check() {
  try {
    const { default: prisma } = await import('../src/lib/db/prisma');
    const projects = await prisma.project.findMany({
      include: {
        audioAssets: {
          orderBy: { createdAt: "desc" },
          take: 1
        }
      }
    });

    console.log(`Total projects: ${projects.length}`);
    for (const p of projects) {
      const audio = p.audioAssets[0];
      console.log(`- Project "${p.title}" (ID: ${p.id}):`);
      console.log(`  Status: ${p.status}`);
      if (audio) {
        console.log(`  Audio ID: ${audio.id}`);
        console.log(`  Sync Source: ${(audio.wordTimestamps as any)?.syncSource}`);
      } else {
        console.log(`  No audio asset.`);
      }
    }
  } catch (e) {
    console.error("Error:", e);
  }
}
check();
