const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
  const projectId = 'cmpmyiyd40000uguq8fefz3sk';
  console.log("Checking project ID:", projectId);

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      scripts: {
        orderBy: { version: 'desc' },
        take: 1
      },
      audioAssets: {
        orderBy: { createdAt: 'desc' },
        take: 1
      }
    }
  });

  if (!project) {
    console.error("Project not found!");
    return;
  }

  console.log("Project Name:", project.name);
  console.log("Latest Script Version:", project.scripts[0]?.version);
  console.log("Latest Script Content:", JSON.stringify(project.scripts[0]?.content));
  
  const latestAudio = project.audioAssets[0];
  if (latestAudio) {
    console.log("Latest Audio Asset:", {
      id: latestAudio.id,
      voiceType: latestAudio.voiceType,
      durationMs: latestAudio.durationMs,
      localPath: latestAudio.localPath,
    });
    console.log("Word Timestamps Count:", latestAudio.wordTimestamps?.words?.length);
    console.log("Word Timestamps sample:", JSON.stringify(latestAudio.wordTimestamps?.words?.slice(0, 10)));
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
