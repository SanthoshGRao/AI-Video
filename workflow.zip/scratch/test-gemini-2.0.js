const fs = require('fs');
async function test() {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "Hello world" }], role: "user" }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Aoede" } } }
      }
    })
  });
  console.log(res.status);
  const json = await res.json();
  console.log(JSON.stringify(json, null, 2));
}
test();
