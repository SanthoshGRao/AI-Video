import fs from "fs";
import path from "path";
import { synthesizeVoiceover } from "../src/lib/tts/synthesize-voiceover";
import { VOICE_PERSONAS } from "../src/lib/tts/voices";
import dotenv from "dotenv";

dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });

async function run() {
  const samples = [
    {
      name: "kannada_places",
      text: "The property is located near Mysore road, close to Mahadevapura and Bannur. It is easily accessible from Narasipura and Mandya, Pandavapura, and Bangalore.",
    },
    {
      name: "kannada_realestate",
      text: "This beautiful villa has 42 coconut trees and is spread across 5 acres. The price is 65 lakh rupees. The layout has 30 feet road access and clear RTC.",
    }
  ];

  const testPersonas = [
    { id: "edge_male", persona: VOICE_PERSONAS["Kannada Male Professional"] },
    { id: "edge_female", persona: VOICE_PERSONAS["Kannada Female Professional"] },
    // Mocking an OpenAI fallback to test how OpenAI would sound
    { id: "openai_male", persona: { ...VOICE_PERSONAS["Kannada Male Professional"], provider: "openai" as const, gptVoice: "ash" as const } },
    { id: "openai_female", persona: { ...VOICE_PERSONAS["Kannada Female Professional"], provider: "openai" as const, gptVoice: "coral" as const } },
  ];

  const outDir = path.join(process.cwd(), "scratch", "benchmark_audio");
  if (!fs.existsSync(outDir)) {
    fs.mkdirSync(outDir, { recursive: true });
  }

  for (const sample of samples) {
    for (const test of testPersonas) {
      console.log(`Generating ${sample.name} using ${test.id}...`);
      try {
        const res = await synthesizeVoiceover(sample.text, test.persona);
        const filename = `${sample.name}_${test.id}.mp3`;
        fs.writeFileSync(path.join(outDir, filename), res.audioBuffer);
        console.log(`Saved ${filename}`);
      } catch (err) {
        console.error(`Failed ${sample.name} - ${test.id}:`, err);
      }
    }
  }
}

run().catch(console.error);
