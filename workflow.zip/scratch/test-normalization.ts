import { synthesizeVoiceover } from '../src/lib/tts/synthesize-voiceover';
import { resolveVoicePersona } from '../src/lib/tts/voices';
import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function test() {
  // Use NRI Property Consultant, configured as an English (India) voice (en-IN)
  const voice = resolveVoicePersona("NRI Property Consultant", "en-IN");
  
  // The exact Kannada text that failed normalization previously
  const text = "ನಿಮ್ಮ ಕನಸುಗಳ ವಿಕಸಿತ ಸ್ಥಳ, ಮೈಸೂರಿನಿಂದ ಕೇವಲ 25 ಕಿಲೋಮೀಟರ್ ದೂರದ ಶಾಂತ ಗ್ರಾಮೀಣ ಪ್ರದೇಶದಲ್ಲಿ. Welcome to this property tour! ತಕ್ಷಣ ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ! Your investment journey starts now!";
  
  try {
    console.log("Synthesizing voiceover with English voice Charon for mixed script...");
    console.log(`Original text length: ${text.length} characters.`);
    
    const res = await synthesizeVoiceover(text, voice);
    
    console.log("\n===========================================");
    console.log("SUCCESS!");
    console.log("===========================================");
    console.log("TTS Provider:", res.ttsProvider);
    console.log("Duration Ms:", res.durationMs);
    console.log("Sync Source:", res.sync.syncSource);
    console.log("Words count:", res.sync.words.length);
    console.log("First 10 Aligned Words:");
    console.dir(res.sync.words.slice(0, 10), { depth: null });
  } catch (err) {
    console.error("\n===========================================");
    console.error("FAILED!", err);
    console.error("===========================================");
  }
}
test();
