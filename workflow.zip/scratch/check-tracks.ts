import prisma from "../src/lib/db/prisma";

async function main() {
  const project = await prisma.project.findFirst({
    orderBy: { updatedAt: "desc" },
    include: {
      timelines: { orderBy: { version: "desc" }, take: 1 }
    }
  });
  console.log("PROJECT ID:", project?.id);
  console.log("TIMELINE VERSION:", project?.timelines[0]?.version);
  console.log("TIMELINE CLIPS:", JSON.stringify(project?.timelines[0]?.clips, null, 2));
}

main().catch(console.error).finally(() => prisma.$disconnect());
