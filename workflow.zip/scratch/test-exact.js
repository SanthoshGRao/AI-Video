const fs = require('fs');
async function test() {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text: "2 point 2 acre farmland near Mysore, ಇದು weekend farmhouse ಗೆ perfect ಪ್ರಶ್ನೆ. Mysuru 25 ಕಿಲೋಮೀಟರ್, tranquil environment, nearby waterfall ಇದೆ. Easy maintenance, irrigation setup ready, water ಆವಶ್ಯಕತೆಗಳ tension ಇಲ್ಲ. Full electricity available ಇದರಿಂದ ಆರಾಮದಾಯಕ setting ಇದೆ. Ideal for calm farmhouse setups. Weekend ಹೋಗಿ fresh breath ಆನಂದಿಸಿ. ಮರೆಯದೆ, ಜೊತೆಗೆ ತಕ್ಷಣ ಸಂಪರ್ಕಿಸಿ. ನನಗೂ ಇದು ಬಿಸಿನೆಸ್ ಆಗಬೇಕು! ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ." }], role: "user" }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Aoede" } } }
      },
      safetySettings: [
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
      ]
    })
  });
  console.log(res.status);
  const json = await res.json();
  console.log(JSON.stringify(json, null, 2));
}
test();
