import prisma from "../src/lib/db/prisma";

async function main() {
  const tracks = await prisma.subtitleTrack.findMany({
    where: { language: "english" }
  });

  console.log(`Found ${tracks.length} english tracks.`);

  for (const t of tracks) {
    console.log(`Track ${t.id} - ${t.projectId}`);
    // Change language back to kannada_english to fix the corruption
    await prisma.subtitleTrack.update({
      where: { id: t.id },
      data: { language: "kannada_english" }
    });
  }
  
  console.log("Fixed all corrupted tracks.");
}

main().catch(console.error);
