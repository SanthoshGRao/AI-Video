const fs = require('fs');
async function test(text) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent?key=AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ parts: [{ text }], role: "user" }],
      generationConfig: {
        responseModalities: ["AUDIO"],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: "Aoede" } } }
      },
      safetySettings: [
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
      ]
    })
  });
  const json = await res.json();
  const finishReason = json.candidates?.[0]?.finishReason;
  console.log(`[${finishReason}] ${text.substring(0, 30)}...`);
}
async function run() {
  const s = "Mysuru twenty five kilometer, tranquil environment, nearby waterfall ide";
  await test(s);
}
run();
