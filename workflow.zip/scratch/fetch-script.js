const { Client } = require('pg');
async function run() {
  const client = new Client({
    connectionString: "postgresql://postgres.skllolmlvhnandptkjeh:santhosh%40123@aws-1-ap-southeast-1.pooler.supabase.com:6543/postgres?pgbouncer=true"
  });
  await client.connect();
  const res = await client.query("SELECT * FROM \"script_versions\" WHERE \"projectId\" = 'cmploxl7t000n70uqaztdgyk1' AND \"isActive\" = true");
  if (res.rows.length > 0) {
    console.log(res.rows[0].content);
  } else {
    console.log("No active script found.");
  }
  await client.end();
}
run();
