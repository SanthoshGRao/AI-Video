import * as dotenv from 'dotenv';
dotenv.config({ path: '.env.local' });

async function dump() {
  try {
    const { default: prisma } = await import('../src/lib/db/prisma');
    const audio = await prisma.audioAsset.findUnique({
      where: { id: "cmpn4b64t000484uqj2zm0omc" }
    });
    if (!audio) {
      console.log("Audio not found!");
      return;
    }
    console.log("Audio URL:", audio.r2Url);
    console.log("DurationMs:", audio.durationMs);
    console.log("Has Waveform Data:", !!audio.waveformData);
    if (audio.waveformData) {
      const arr = audio.waveformData as any[];
      console.log("Waveform Length:", arr.length);
      console.log("Waveform Preview:", arr.slice(0, 10));
    }
  } catch (e) {
    console.error("Error:", e);
  }
}
dump();
