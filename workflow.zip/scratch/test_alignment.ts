import { WordTimestamp } from "../src/lib/tts/types";

export function forceAlignToScript(
  displayScript: string,
  whisperWords: WordTimestamp[]
): WordTimestamp[] {
  if (!whisperWords || whisperWords.length === 0) return [];
  const originalWords = displayScript.split(/\s+/).filter(w => w.trim().length > 0);
  if (originalWords.length === 0) return [];

  const aligned: WordTimestamp[] = [];
  
  for (let i = 0; i < originalWords.length; i++) {
    const origWord = originalWords[i];
    
    // Map based on word index ratio
    const startIndexRatio = i / originalWords.length;
    const endIndexRatio = (i + 1) / originalWords.length;
    
    // Find the corresponding whisper words for this range
    const startWIndex = Math.floor(startIndexRatio * whisperWords.length);
    const endWIndex = Math.max(startWIndex, Math.floor(endIndexRatio * whisperWords.length) - 1);
    
    let start = whisperWords[startWIndex].start;
    let end = whisperWords[endWIndex].end;

    if (aligned.length > 0) {
      const prevEnd = aligned[aligned.length - 1].end;
      if (start < prevEnd) start = prevEnd;
      if (end < start + 0.05) end = start + 0.1;
    }

    aligned.push({
      word: origWord,
      start,
      end
    });
  }

  return aligned;
}

const displayScript = "Welcome to Mysore. This villa costs 65 lakh.";
const whisperWords = [
  { word: "ವೆಲ್ಕಮ್", start: 0, end: 0.5 },
  { word: "ಟು", start: 0.5, end: 0.8 },
  { word: "ಮೈಸೂರು", start: 0.8, end: 1.5 },
  { word: "ದಿಸ್", start: 2.0, end: 2.3 },
  { word: "ವಿಲ್ಲಾ", start: 2.3, end: 2.8 },
  { word: "ಕಾಸ್ಟ್ಸ್", start: 2.8, end: 3.5 },
  { word: "ಅರವತ್ತೈದು", start: 3.5, end: 4.5 },
  { word: "ಲಕ್ಷ", start: 4.5, end: 5.0 },
];

console.log(forceAlignToScript(displayScript, whisperWords));
