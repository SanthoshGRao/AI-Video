const fs = require('fs');
async function test() {
  const apiKey = "AIzaSyDWScRYnUcENcSz-LDv9aUT5NbrM2ni3V0";
  const targetLang = "Kannada";
  const text = "Mysuru 25 ಕಿಲೋಮೀಟರ್, tranquil environment, nearby waterfall ಇದೆ. Easy maintenance, irrigation setup ready, water ಆವಶ್ಯಕತೆಗಳ tension ಇಲ್ಲ. Full electricity available ಇದರಿಂದ ಆರಾಮದಾಯಕ setting ಇದೆ. Ideal for calm farmhouse setups. Weekend ಹೋಗಿ fresh breath ಆನಂದಿಸಿ. ಮರೆಯದೆ, ಜೊತೆಗೆ ತಕ್ಷಣ ಸಂಪರ್ಕಿಸಿ. ನನಗೂ ಇದು ಬಿಸಿನೆಸ್ ಆಗಬೇಕು! ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ.";

  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{
        parts: [{
          text: `Transliterate all English words in this text into ${targetLang} script phonetically. Output ONLY the resulting mixed ${targetLang} string without any English characters. Do not translate the meaning, just transliterate phonetically. Text:\n${text}`
        }],
        role: "user"
      }]
    })
  });
  
  const json = await res.json();
  const transliterated = json.candidates?.[0]?.content?.parts?.[0]?.text;
  console.log("LLM Output:", transliterated);
}
test();
