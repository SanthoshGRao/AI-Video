import dotenv from "dotenv";
dotenv.config({ path: ".env.local" });

async function main() {
  const { prisma } = await import("../src/lib/db/prisma");
  const projectId = 'cmpmyiyd40000uguq8fefz3sk';
  console.log("Checking project ID:", projectId);

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      scriptVersions: {
        orderBy: { versionNumber: 'desc' },
        take: 1
      },
      audioAssets: {
        orderBy: { createdAt: 'desc' },
        take: 1
      }
    }
  });

  if (!project) {
    console.error("Project not found!");
    return;
  }

  console.log("Latest Script Version:", project.scriptVersions[0]?.versionNumber);
  console.log("Latest Script Content:", JSON.stringify(project.scriptVersions[0]?.content));
  
  const latestAudio = project.audioAssets[0];
  if (latestAudio) {
    console.log("Latest Audio Asset:", {
      id: latestAudio.id,
      voiceType: latestAudio.voiceType,
      durationMs: latestAudio.durationMs,
      localPath: latestAudio.localPath,
    });
    const timestamps = latestAudio.wordTimestamps as any;
    console.log("Word Timestamps Count:", timestamps?.words?.length);
    console.log("Word Timestamps sample:", JSON.stringify(timestamps?.words?.slice(0, 10)));
  }
}

main().catch(console.error);
