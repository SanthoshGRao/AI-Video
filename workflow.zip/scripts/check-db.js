const { Pool } = require("pg");
const { PrismaPg } = require("@prisma/adapter-pg");
const { PrismaClient } = require("../src/generated/prisma/client");
require("dotenv").config({ path: "../.env" });

async function main() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) throw new Error("DATABASE_URL is not set");

  const pool = new Pool({ connectionString });
  const adapter = new PrismaPg(pool);
  const prisma = new PrismaClient({ adapter });

  const projectId = "cmqwsgtur0000pouqz10nl5as";

  const jobs = await prisma.exportJob.findMany({
    where: { projectId },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  jobs.forEach((j, i) => {
    console.log(`Job ${i}: ${j.id} | ${j.status} | Progress: ${j.renderProgress} | Error: ${j.errorMessage || "none"}`);
  });

  await prisma.$disconnect();
  await pool.end();
}
main().catch(console.error);
