import { NextResponse } from "next/server";
import { Prisma } from "@/generated/prisma/client";
import prisma from "@/lib/db/prisma";
import { generateText } from "ai";
import { defaultModel } from "@/lib/ai/client";
import { extractFactsFromText } from "@/lib/ai/extract-facts";
import { requireProjectAccess } from "@/lib/auth/require-project";
import { handleRouteError, badRequest } from "@/lib/api/errors";
import { generateScriptBodySchema } from "@/lib/validations/upload";
import { trackEvent } from "@/lib/analytics/track";
import { getNextScriptBatchMeta, VARIATIONS } from "@/lib/scripts/versioning";
import {
  canGenerateScripts,
  createEnvelopeFromExtracted,
  parseEnvelope,
} from "@/lib/facts/envelope";
import { factSchema } from "@/lib/ai/extract-facts";

const LANGUAGE_INSTRUCTIONS: Record<string, string> = {
  english: `Write the script entirely in English.
Strict TTS-ready rules:
- Format all decimal numbers by writing them out with 'point' as text (e.g. '1.22' must be written as '1 point 22') to ensure correct pronunciation by text-to-speech engines. Do NOT use dot notation (like '1.22') in the script.
- Ensure the script is natural, conversational, and direct.`,

  kannada: `Write the script entirely in Kannada (ಕನ್ನಡ) — no English words except unavoidable proper nouns.
Strict TTS-ready rules:
- Format all decimal numbers by writing them out using the English word 'point' as text (e.g. '1.22' must be written as '1 point 22') to ensure correct pronunciation by text-to-speech engines. Do NOT use dot notation (like '1.22') in the script.
- Write other numbers in digits.`,

  kannada_english: `You are writing a Kanglish (Kannada + English) voiceover script that sounds EXACTLY like how a local Karnataka real estate agent speaks — natural, confident, human.

══════════════════════════════════════
CORE GRAMMAR RULE — READ THIS FIRST
══════════════════════════════════════
The SENTENCE SKELETON is always Kannada. English words/phrases are EMBEDDED inside it.
The sentence always ENDS with a Kannada verb or particle.

✅ CORRECT patterns:
  "30 feet road access ಇದೆ"
  "Drip irrigation done ಆಗಿದೆ, maintenance easy ಆಗ್ತದೆ"
  "Legal side clear ಇದೆ, RTC available ಇದೆ"
  "Borewell ಇದೆ, electricity ಕೂಡ ಇದೆ"
  "Investment ಗೆ bahala good option ಇದು"
  "ಮೈಸೂರಿನಿಂದ 25 ಕಿಲೋಮೀಟರ್ ದೂರದಲ್ಲಿ, entry smooth ಆಗಿದೆ"

❌ NEVER DO THIS:
  "The road access is excellent with 30 feet width." ← Full English sentence, WRONG
  "ರಸ್ತೆ ಮೂವತ್ತು ಅಡಿ ಅಗಲ ಇದೆ" ← Full Kannada, WRONG (must embed English)
  "Road. Borewell. Electricity. RTC." ← Staccato list, no Kannada connectors, WRONG
  "ಡ್ರಿಪ್ ಇರಿಗೇಶನ್ ಮಾಡಿದ್ದಾರೆ" ← Transliterating English into Kannada script, WRONG
  "Good location ಇದೆ nice property ಇದೆ" ← Vague filler words, WRONG

══════════════════════════════════════
APPROVED KANNADA PARTICLES & CONNECTORS
══════════════════════════════════════
Only use these spoken Kannada forms — do NOT invent or guess other Kannada:

Existence:       ಇದೆ · ಇಲ್ಲ · ಇದ್ದಾರೆ
Completed action: ಆಗಿದೆ · ಮಾಡಿದ್ದಾರೆ · ಮಾಡಿ · ಆಗ್ತದೆ
Addition:         ಕೂಡ · ಜೊತೆಗೆ · ಮತ್ತು
Distance/unit:    ಕಿಲೋಮೀಟರ್ · ಏಕರೆ · ಲಕ್ಷ
Emphasis:         ಬಹಳ (or "bahala") · ಕೇವಲ · ನೇರವಾಗಿ
Engagement:       ನೋಡಿ · ಅಲ್ವಾ · ತಿಳಿದ್ರೆ
Purpose:          ಗಾಗಿ · ಗೇ
Casual/spoken:    ಇದ್ರೆ · ಆದ್ರೆ · ಅಂದ್ರೆ

══════════════════════════════════════
WHAT TO WRITE IN ENGLISH (always, never translate)
══════════════════════════════════════
- All NUMBERS: "30 feet", "65 lakhs", "25 kilometers", "42 trees"
- Legal/technical: RTC, drip irrigation, borewell, electricity, legal clarity
- Real estate terms: road access, entry, maintenance, price per acre, serious buyers
- Property state: "done", "available", "clear", "ready", "sorted"
- Location proper nouns: Mysuru, Bangalore, Bannur

══════════════════════════════════════
DECIMAL RULE (critical for TTS)
══════════════════════════════════════
NEVER write a decimal point. Always expand:
  "1.22 acres" → "1 point 22 acre"
  "6.5 lakhs" → "6 point 5 lakhs"
  "12.5 km" → "12 point 5 ಕಿಲೋಮೀಟರ್"

══════════════════════════════════════
HUMAN-LIKE FLOW RULES
══════════════════════════════════════
- Open with a hook that creates curiosity or emotion — NOT a location fact
- Group related facts naturally (water facts together, legal facts together, location together)
- Vary sentence rhythm: short punchy sentence → slightly longer → short again
- DO NOT recite facts like a list — connect them with "ಜೊತೆಗೆ", "ಕೂಡ", "ಅದರ ಜೊತೆಗೆ"
- Build toward excitement near the CTA, do not trail off flatly

══════════════════════════════════════
CALL TO ACTION (fixed, do not change)
══════════════════════════════════════
Always end with exactly:
"ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ"
(Write "D M" with a space between the letters — required for TTS)

══════════════════════════════════════
REFERENCE SCRIPT (style guide only — do NOT copy content, use your own facts)
══════════════════════════════════════
Variation: "Premium + Clear facts":
ಒಂದು seriously good farmland deal ನೋಡಿ. 1 point 22 acre coconut farmland, ಮೈಸೂರಿನಿಂದ ಕೇವಲ 25 ಕಿಲೋಮೀಟರ್. Shooting Mahadevapura ಇಂದ 5 ಕಿಲೋಮೀಟರ್, ಬನ್ನೂರು 8 ಕಿಲೋಮೀಟರ್, T Narasipura 28 ಕಿಲೋಮೀಟರ್. Road ವಿಷಯ ಹೇಳಬೇಕಂದ್ರೆ, 30 feet road access ಇದೆ, entry bahala smooth ಆಗಿದೆ. Plantation ವಿಚಾರಕ್ಕೆ ಬಂದ್ರೆ, 42 ತೆಂಗಿನ ಮರಗಳು ready ಆಗಿದೆ, drip irrigation ಕೂಡ done ಆಗಿದೆ, ಹಾಗಾಗಿ maintenance ಬಹಳ easy ಆಗ್ತದೆ. Water tension ಅಂತ ಇಲ್ಲ — 1 borewell ಇದೆ, electricity availability ಕೂಡ ಇದೆ. Legal side ನೋಡಿ, full clear, RTC available ಇದೆ. Price ವಿಷಯಕ್ಕೆ ಬಂದ್ರೆ, per acre 65 lakhs, slightly negotiable — serious buyers ಮಾತ್ರ contact ಮಾಡಿ. ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ.

Variation: "Emotional + Weekend farmhouse":
ನಿಮ್ಮ ಕನಸಿನ weekend farmhouse ಒಂದು real ಆಗ್ಲಿ ಅಂತ ಅನ್ಸತ್ತಾ? ಇಲ್ಲಿ ನೋಡಿ. ಮೈಸೂರಿನಿಂದ 25 ಕಿಲೋಮೀಟರ್ ದೂರದಲ್ಲಿ, ಬನ್ನೂರು ಹತ್ರ 1 point 22 acre coconut land ಇದೆ. ಸಿಟಿ crowd ಇಲ್ಲ, pollution ಇಲ್ಲ — ಆದ್ರೆ Bangalore ಇಂದ 120 ಕಿಲೋಮೀಟರ್ ಅಷ್ಟೇ. 30 feet road access ಇದೆ, ಯಾವ time ಬಂದ್ರೂ entry smooth. 42 ತೆಂಗಿನ ಮರಗಳ plantation ಇದೆ, drip irrigation done ಆಗಿದೆ — ನೀವು ಇಲ್ಲಿ ಇರಲಿ ಬಿಡಲಿ, land ತನ್ನಷ್ಟಕ್ಕೆ ತಾನೆ ಕೆಲಸ ಮಾಡ್ತದೆ. Borewell ಇದೆ, electricity ಕೂಡ ಇದೆ. Documents clear, RTC available. Price per acre 65 lakhs, slightly negotiable. ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ.

Variation: "Urgent + Fast deal":
ಇದು fast moving property, ನಿಧಾನ ಮಾಡ್ಬೇಡಿ. ಮೈಸೂರು ಬಳಿ 1 point 22 acre coconut farmland, ಬನ್ನೂರಿನಿಂದ 8 ಕಿಲೋಮೀಟರ್, Shooting Mahadevapura 5 ಕಿಲೋಮೀಟರ್. Road access? 30 feet, entry smooth ಆಗಿದೆ. Plantation? 42 ತೆಂಗಿನ ಮರಗಳು, drip irrigation already done. Water? Borewell ready, electricity ಕೂಡ ಇದೆ. Legal? RTC available, zero tension. Price? Per acre 65 lakhs, slightly negotiable — ಆದ್ರೆ serious buyers ಮಾತ್ರ. ಸೈಟ್ ವಿಸಿಟ್ ಗೇ WhatsApp ನಲ್ಲಿ D M ಮಾಡಿ.`,

  hindi_english: `Write the script in a natural, highly engaging conversational hybrid mix of Hindi (हिन्दी) and English (commonly known as Hinglish), roughly 50/50 mix.

Style Guidelines:
- Decimals: Format all decimal numbers by writing them out with the English word 'point' as text (e.g. '1.22' must be written as '1 point 22') to ensure correct pronunciation by text-to-speech engines. Do NOT use dot notation (like '1.22') in the script.
- Numbers/Quantities: Use English digits for measurements, sizes, prices, distances, and road widths (e.g. "30 feet road", "65 lakhs", "25 किलोमीटर", "42 नारियल के पेड़").
- Technical/Legal property facts: Use English terms (e.g., "RTC available", "drip irrigation done", "borewell", "electricity available", "legal clarity", "smooth entry").
- Sentence Flow: Connect facts with natural conversational Hindi verbs and particles.
- Sentence Structure: Do NOT generate full English sentences. The overall sentence structure must be Hindi-driven, ending in Hindi verbs/particles. Only embed English nouns, adjectives, or short phrases inside the Hindi flow.
- Call to Action: Use a hybrid phrasing like "साइट विजिट के लिए WhatsApp पर D M करें".`,
};

type RouteContext = { params: Promise<{ id: string }> };

export async function POST(request: Request, context: RouteContext) {
  try {
    const { id } = await context.params;
    const { user } = await requireProjectAccess(id);

    let body = {};
    try {
      const raw = await request.json();
      body = generateScriptBodySchema.parse(raw);
    } catch {
      body = {};
    }

    const project = await prisma.project.findUnique({
      where: { id },
      include: { template: true },
    });

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const propertyData = project.propertyData as { rawText?: string } | null;
    const rawText = propertyData?.rawText?.trim() ?? "";

    let factsToUse: Record<string, unknown> | null = null;
    let envelope = parseEnvelope(project.validatedFacts);

    if (!project.extractedFacts) {
      if (!rawText) {
        throw badRequest("Add property details before generating scripts.");
      }
      const extracted = await extractFactsFromText(
        rawText,
        project.template?.aiSystemPrompt
      );
      await prisma.project.update({
        where: { id },
        data: {
          extractedFacts: extracted as object,
          validatedFacts: Prisma.DbNull,
          status: "CONTENT_READY",
        },
      });
      throw badRequest(
        "Facts extracted. You can generate scripts from the Scripts tab."
      );
    }

    if (!envelope && rawText) {
      envelope = createEnvelopeFromExtracted(
        factSchema.parse(project.extractedFacts),
        rawText
      );
    }

    if (!canGenerateScripts(envelope, !!project.extractedFacts)) {
      throw badRequest("Extract property facts before generating scripts.");
    }

    factsToUse = envelope!.data as Record<string, unknown>;

    const templatePrompt =
      project.template?.aiSystemPrompt || "General real estate property.";
    const scriptStrategy =
      project.template?.scriptStrategy || "Engaging and professional layout.";

    const { nextBatch, startVersion } = await getNextScriptBatchMeta(project.id);

    const generatedScripts = await Promise.all(
      VARIATIONS.map(async (v, index) => {
        const targetWordCount = Math.round((project.durationSeconds || 30) * 2.5);
        const minWordCount = Math.max(targetWordCount - 15, 0);

        const prompt = `
You are a senior Kannada real estate voiceover writer who has written 500+ scripts for Instagram Reels and YouTube Shorts. You know exactly how a local agent talks.

━━━ ASSIGNMENT ━━━
Write ONE voiceover script in the "${v.style}" style for a ${project.durationSeconds}-second property video.
Target word count: ${targetWordCount} words (min ${minWordCount} words — you WILL be penalized for going under).

━━━ VOICE & FEEL ━━━
Tone: ${project.tone}
Target audience: ${project.targetAudience || "General buyers"}
CTA style: ${project.ctaStyle}
Variation angle: ${v.angle}

━━━ LANGUAGE RULES ━━━
${LANGUAGE_INSTRUCTIONS[project.language] || LANGUAGE_INSTRUCTIONS.english}

━━━ CONTENT STRATEGY ━━━
Template context: ${templatePrompt}
Script strategy: ${scriptStrategy}

Use ONLY these verified property facts — do NOT add or invent facts:
${JSON.stringify(factsToUse, null, 2)}

To reach the word count naturally:
- Expand on WHY each feature matters to the buyer (not just what it is)
- Paint a picture of daily life or investment value at this location
- Make transitions between facts feel like a conversation, not a checklist

━━━ OUTPUT FORMAT RULES (STRICT) ━━━
1. Output ONLY the spoken script — no titles, no headers, no "Here is your script:"
2. NO stage directions, NO bracketed cues [Video], [Music], [SFX]
3. NO markdown: no bold, no italics, no bullet points, no dashes
4. NO emojis — they break TTS
5. Decimals: ALWAYS expand — "1.22" → "1 point 22", never use a dot
6. Just raw flowing paragraphs, exactly as someone would speak it
`;

        const { text } = await generateText({
          model: defaultModel,
          prompt,
        });

        const trimmed = text.trim();
        const wordCount = trimmed.split(/\s+/).length;

        return {
          projectId: project.id,
          generationBatch: nextBatch,
          versionNumber: startVersion + index + 1,
          variationStyle: v.style,
          content: trimmed,
          language: project.language,
          wordCount,
          estimatedDuration: Math.round(wordCount / 2.5),
          isActive: true,
          isApproved: false,
        };
      })
    );

    const savedScripts = await prisma.$transaction(async (tx) => {
      await tx.scriptVersion.updateMany({
        where: { projectId: project.id },
        data: { isActive: false },
      });

      await tx.scriptVersion.createMany({ data: generatedScripts });

      return tx.scriptVersion.findMany({
        where: { projectId: project.id, generationBatch: nextBatch },
        orderBy: { versionNumber: "asc" },
      });
    });

    await trackEvent(user.id, "scripts_generated", {
      projectId: project.id,
      generationBatch: nextBatch,
      count: savedScripts.length,
    });

    return NextResponse.json({
      scripts: savedScripts,
      generationBatch: nextBatch,
    });
  } catch (error) {
    return handleRouteError(error);
  }
}
